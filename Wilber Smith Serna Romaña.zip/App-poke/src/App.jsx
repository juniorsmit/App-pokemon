import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

// Componente de la página de inicio
const Home = ({ addFavorite }) => {
  const [pokemons, setPokemons] = useState([]);

  useEffect(() => {
    axios.get('https://pokeapi.co/api/v2/pokemon?limit=20')
      .then(response => setPokemons(response.data.results))
      .catch(error => console.error(error));
  }, []);

  return (
    <div>
      <h1>Pokémon List</h1>
      <ul>
        {pokemons.map((pokemon, index) => (
          <li key={index}>
            <Link to={`/pokemon/${pokemon.name}`}>{pokemon.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

//Detalles de la pagina
const Detail = ({ addFavorite, removeFavorite, favorites }) => {
  const { id } = useParams();
  const [pokemon, setPokemon] = useState(null);

  useEffect(() => {
    axios.get(`https://pokeapi.co/api/v2/pokemon/${id}`)
      .then(response => setPokemon(response.data))
      .catch(error => console.error(error));
  }, [id]);

  const isFavorite = favorites.some(fav => fav.name === pokemon?.name);

  return (
    <div>
      {pokemon ? (
        <div>
          <h1>{pokemon.name}</h1>
          <img src={pokemon.sprites.front_default} alt={pokemon.name} />
          <p>Height: {pokemon.height}</p>
          <p>Weight: {pokemon.weight}</p>
          <button onClick={() => isFavorite ? removeFavorite(pokemon) : addFavorite(pokemon)}>
            {isFavorite ? "Eliminar de favoritos" : "Agregar a favoritos"}
          </button>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

//Componentes favoritos de la pagina
const Favorites = ({ favorites, removeFavorite }) => (
  <div>
    <h1>Favorites</h1>
    <ul>
      {favorites.map((pokemon, index) => (
        <li key={index}>
          {pokemon.name} 
          <button onClick={() => removeFavorite(pokemon)}>Eliminar</button>
        </li>
      ))}
    </ul>
  </div>
);

// Componente principal de la aplicación
const App = () => {
  const [favorites, setFavorites] = useState([]);

  const addFavorite = (pokemon) => {
    if (!favorites.some(fav => fav.name === pokemon.name)) {
      setFavorites([...favorites, pokemon]);
    }
  };

  const removeFavorite = (pokemon) => {
    setFavorites(favorites.filter(fav => fav.name !== pokemon.name));
  };

  return (
    <Router>
      <nav>
        <Link to="/">Home</Link> | <Link to="/favorites">Favorites</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home addFavorite={addFavorite} />} />
        <Route path="/pokemon/:id" element={<Detail addFavorite={addFavorite} removeFavorite={removeFavorite} favorites={favorites} />} />
        <Route path="/favorites" element={<Favorites favorites={favorites} removeFavorite={removeFavorite} />} />
      </Routes>
    </Router>
  );
};

export default App;
